//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//@WebServlet("/loginsuccessful")
//public class loginsuccessful extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        HttpSession session = request.getSession(false);
//        
//        if (session == null || session.getAttribute("userName") == null) {
//            response.sendRedirect("login.jsp");
//            return;
//        }
//
//        String userName = (String) session.getAttribute("userName");
//        String dbURL = "jdbc:mysql://localhost:3306/registerdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
//        String dbUser = "root";
//        String dbPass = "";
//
//        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
//            String sql = "SELECT * FROM usersN WHERE username=?";
//            PreparedStatement ps = conn.prepareStatement(sql);
//            ps.setString(1, userName);
//            ResultSet rs = ps.executeQuery();
//
//            if (rs.next()) {
//                request.setAttribute("fullName", rs.getString("fullName"));
//                request.setAttribute("email", rs.getString("email"));
//                request.setAttribute("phone", rs.getString("phone"));
//                request.setAttribute("gender", rs.getString("gender"));
//                request.setAttribute("dob", rs.getString("dob"));
//                request.setAttribute("address", rs.getString("address"));
//                request.setAttribute("country", rs.getString("country"));
//                request.getRequestDispatcher("LoginSuccessful.jsp").forward(request, response);
//            } else {
//                response.sendRedirect("login.jsp");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            response.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
//        }
//    }
//}
